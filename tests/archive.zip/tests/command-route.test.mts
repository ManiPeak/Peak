/**
 * تست‌های مسیر فرمان ماینکرفت (/api/minecraft/command)
 *
 * رگرسیون باگ «فرمان‌های توانایی بی‌صدا رد می‌شدند»: باکس فرمان صفحهٔ ماینکرفت
 * باید به موتور توانایی‌ها (مثل مهروموم خدایی) برسد، نه فقط دستورهای حرکتی.
 */
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const TMP_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "peak-cmdroute-test-"));
process.env.DASTIAR_DB_PATH = path.join(TMP_DIR, "test.sqlite");
process.env.PEAK_LOG_LEVEL = "error";

const { POST } = await import("@/app/api/minecraft/command/route");
const { saveSettings } = await import("@/lib/store");

function cmd(text: string): Request {
  return new Request("http://localhost/api/minecraft/command", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });
}

describe("مسیر فرمان — رسیدن فرمان‌ها به موتور توانایی‌ها", () => {
  before(() => {
    saveSettings({
      mcPlayLevel: "normal",
      mcIsOp: true,
      userName: "ManiPeak",
      mcFriends: [],
      mcProtectTarget: null
    });
  });

  after(() => {
    fs.rmSync(TMP_DIR, { recursive: true, force: true });
  });

  test("متن خالی ۴۰۰ می‌شود", async () => {
    const res = await POST(cmd("") as never);
    assert.equal(res.status, 400);
  });

  test("فرمان مهروموم خدایی به موتور توانایی‌ها می‌رسد (گیت سطح بازی)", async () => {
    const res = await POST(cmd("مهروموم خدایی روی Ali") as never);
    const json = (await res.json()) as { ok: boolean; reply: string; command: string };
    assert.equal(json.command, "fast", "باید از مسیر توانایی‌ها اجرا شود");
    assert.equal(json.ok, false);
    assert.match(json.reply, /فقط در سطح بازی «خدا»/, "پیام گیت سطح خدا باید برگردد");
  });

  test("در سطح خدا، پیام اتصال می‌آید (نه پاسخ خالی)", async () => {
    saveSettings({ mcPlayLevel: "god" });
    const res = await POST(cmd("مهروموم خدایی روی Ali") as never);
    const json = (await res.json()) as { ok: boolean; reply: string; command: string };
    assert.equal(json.command, "fast");
    assert.match(json.reply, /به سروری وصل نیستم/, "پیام دقیق اتصال باید برگردد");
    saveSettings({ mcPlayLevel: "normal" });
  });

  test("دستورهای حرکتی قبلی دست‌نخورده‌اند", async () => {
    const res = await POST(cmd("بیا دنبالم") as never);
    const json = (await res.json()) as { ok: boolean; reply: string; command: string };
    assert.equal(json.command, "follow");
    assert.match(json.reply, /به سروری وصل نیستم/);
  });
});
