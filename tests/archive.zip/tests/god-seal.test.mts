/**
 * تست‌های مهروموم خدایی (Divine Seal) و نبرد خدایی (God PvP)
 *
 * پوشش: فعال‌سازی در سطح خدا | عدم دسترسی در سطوح نامرتبط | ترکیب با PvP |
 * محافظت از دوستان | خطاها و توقف عملیات
 *
 * همهٔ مسیرها واقعی اجرا می‌شوند (executeCapability / matchFastAction)؛
 * فقط «بدن» ربات با شیء جعلی کنترل‌شده جایگزین می‌شود.
 */
import { test, describe, before, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const TMP_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "peak-godseal-test-"));
process.env.DASTIAR_DB_PATH = path.join(TMP_DIR, "test.sqlite");
process.env.PEAK_LOG_LEVEL = "error";

const { botManager } = await import("@/minecraft/botManager");
const { executeCapability, matchFastAction, getSealedPlayers } = await import(
  "@/minecraft/actions"
);
const { saveSettings } = await import("@/lib/store");

/* ---------------- ابزارهای تست ---------------- */

type FakePos = { x: number; y: number; z: number; distanceTo(o: { x: number; y: number; z: number }): number };

function mkPos(x: number, y: number, z: number): FakePos {
  return {
    x,
    y,
    z,
    distanceTo(o) {
      return Math.hypot(x - o.x, y - o.y, z - o.z);
    }
  };
}

interface FakeEntity {
  type: string;
  username: string;
  name: string;
  position: FakePos;
}

/** شیء جعلی کنترل‌شده به‌جای بدنهٔ mineflayer — همهٔ تعامل‌ها ضبط می‌شوند */
function mkFakeBot(opts?: { aliDist?: number; health?: number; onlyFriend?: boolean }) {
  const chats: string[] = [];
  const attacks: string[] = [];
  const controls: string[] = [];
  const botEntity: FakeEntity = {
    type: "player",
    username: "PeakBot",
    name: "PeakBot",
    position: mkPos(0, 64, 0)
  };
  const ali: FakeEntity = {
    type: "player",
    username: "Ali",
    name: "Ali",
    position: mkPos(opts?.aliDist ?? 5, 64, 0)
  };
  const dost: FakeEntity = {
    type: "player",
    username: "Dost",
    name: "Dost",
    position: mkPos(3, 64, 0)
  };
  const players: Record<string, { entity: FakeEntity }> = {
    PeakBot: { entity: botEntity },
    Dost: { entity: dost }
  };
  const entities: Record<string, FakeEntity> = { e0: botEntity, e2: dost };
  if (!opts?.onlyFriend) {
    players.Ali = { entity: ali };
    entities.e1 = ali;
  }
  const fake = {
    username: "PeakBot",
    health: opts?.health ?? 20,
    food: 20,
    entity: botEntity,
    players,
    entities,
    game: { dimension: "overworld" },
    chat: (t: string) => {
      chats.push(t);
    },
    attack: (e: FakeEntity) => {
      attacks.push(e.username);
    },
    setControlState: (k: string, v: boolean) => {
      controls.push(`${k}=${v}`);
    }
  };
  return { fake, chats, attacks, controls };
}

type BotHolder = { bot: unknown };
const manager = botManager as unknown as BotHolder;
const originalBot = manager.bot;

let chats: string[] = [];
let attacks: string[] = [];
let controls: string[] = [];

function installBot(opts?: Parameters<typeof mkFakeBot>[0]): void {
  const built = mkFakeBot(opts);
  manager.bot = built.fake;
  chats = built.chats;
  attacks = built.attacks;
  controls = built.controls;
}

const ctx = { player: "ManiPeak", isOp: true };

/* ---------------- تست‌ها ---------------- */

describe("مهروموم خدایی (Divine Seal) — زیرمجموعهٔ حالت خدا", () => {
  before(() => {
    saveSettings({
      mcPlayLevel: "god",
      mcIsOp: false,
      userName: "ManiPeak",
      mcProtectTarget: null,
      mcFriends: ["Dost"]
    });
    installBot();
  });

  beforeEach(async () => {
    installBot();
    saveSettings({ mcPlayLevel: "god", mcIsOp: false, mcFriends: ["Dost"] });
    // پاک‌سازی وضعیت مهروموم بین تست‌ها — از همان مسیر «توقف عملیات»
    await executeCapability("god_seal_off", {}, ctx);
    chats.length = 0;
    attacks.length = 0;
    controls.length = 0;
  });

  after(() => {
    manager.bot = originalBot;
    fs.rmSync(TMP_DIR, { recursive: true, force: true });
  });

  test("آزمون فعال‌سازی مهروموم خدایی در سطح خدا", async () => {
    const res = await executeCapability("god_seal_on", { player: "Ali" }, ctx);
    assert.equal(res.ok, true, `باید ok باشد: ${res.reply}`);
    assert.match(res.reply, /مهروموم خدایی/);
    assert.match(res.reply, /«Ali»/);
    // فرمان‌های واقعی سرور — مهروموم کامل
    assert.ok(chats.includes("/tag Ali add peak_sealed"), "تگ مهروموم ثبت نشد");
    assert.ok(chats.includes("/effect give Ali slowness 999 255"), "کندی اعمال نشد");
    assert.ok(chats.includes("/effect give Ali weakness 999 255"), "ناتوانی اعمال نشد");
    assert.ok(chats.includes("/effect give Ali mining_fatigue 999 255"), "خستگی حفاری اعمال نشد");
    assert.ok(chats.includes("/gamemode adventure Ali"), "حالت ماجراجویی اعمال نشد");
    assert.ok(getSealedPlayers().includes("Ali"), "در فهرست مهروموم‌شده‌ها نیست");
    // فرمان زبان طبیعی فارسی و انگلیسی
    const fa = matchFastAction("مهروموم خدایی روی Ali");
    assert.equal(fa?.id, "god_seal_on");
    assert.equal(fa?.args.player, "Ali");
    const en = matchFastAction("divine seal on Ali");
    assert.equal(en?.id, "god_seal_on");
    assert.equal(en?.args.player, "Ali");
  });

  test("آزمون عدم دسترسی در سطوح نامرتبط (مبتدی/عادی/حرفه‌ای)", async () => {
    for (const lvl of ["beginner", "normal", "pro"] as const) {
      saveSettings({ mcPlayLevel: lvl });
      const seal = await executeCapability("god_seal_on", { player: "Ali" }, ctx);
      assert.equal(seal.ok, false, `سطح ${lvl} نباید اجازه دهد`);
      assert.match(seal.reply, /فقط در سطح بازی «خدا»/);
      const pvp = await executeCapability("god_pvp", { player: "Ali" }, ctx);
      assert.equal(pvp.ok, false, `نبرد خدایی در سطح ${lvl} نباید اجرا شود`);
      assert.match(pvp.reply, /فقط در سطح بازی «خدا»/);
    }
    assert.equal(chats.length, 0, "هیچ فرمانی نباید اجرا می‌شد");
    assert.equal(getSealedPlayers().length, 0);
    // اما «باز کردن مهروموم» (توقف) حتی خارج از سطح خدا در دسترس است
    const off = await executeCapability("god_seal_off", {}, ctx);
    assert.equal(off.ok, true);
  });

  test("آزمون ترکیب با PvP — نبرد خدایی ۵ مرحله‌ای", async () => {
    installBot();
    saveSettings({ mcPlayLevel: "god", mcIsOp: true });
    const res = await executeCapability("god_pvp", { player: "Ali" }, ctx);
    assert.equal(res.ok, true, `باید ok باشد: ${res.reply}`);
    assert.match(res.reply, /نبرد خدایی/);
    assert.match(res.reply, /مهروموم/);
    assert.match(res.reply, /ادامه می‌دهم/);
    // ۳) نبرد واقعی: ضربه + اتوکلیک + تلپورت نزدیک هدف
    assert.ok(attacks.includes("Ali"), "ضربه به دشمن نخورد");
    assert.equal(
      (botManager as unknown as { autoAttack: boolean }).autoAttack,
      true,
      "اتوکلیک باید روشن شود"
    );
    assert.ok(
      chats.some((c) => c.startsWith("/tp PeakBot")),
      "تلپورت نزدیک هدف انجام نشد"
    );
    // هماهنگی با سطح خدا: حالت خدا روی خودم
    assert.ok(
      chats.includes("/effect give PeakBot resistance 999 4"),
      "آماده‌سازی حالت خدا انجام نشد"
    );
    // ۴) مهروموم خدایی روی دشمن
    assert.ok(chats.includes("/tag Ali add peak_sealed"));
    assert.ok(chats.includes("/gamemode adventure Ali"));
    // ۵) بدون هدف مشخص ← نزدیک‌ترین دشمن غیردوست (منطق موجود) — دوست هرگز
    chats.length = 0;
    attacks.length = 0;
    const auto = await executeCapability("god_pvp", {}, ctx);
    assert.equal(auto.ok, true, `انتخاب خودکار هدف: ${auto.reply}`);
    assert.ok(attacks.includes("Ali"));
    assert.ok(!attacks.includes("Dost"), "به دوست نباید حمله شود");
  });

  test("آزمون محافظت از دوستان", async () => {
    // مهروموم روی دوست ← هرگز
    const seal = await executeCapability("god_seal_on", { player: "Dost" }, ctx);
    assert.equal(seal.ok, false);
    assert.match(seal.reply, /دوست/);
    // نبرد خدایی با دوست ← هرگز
    const pvp = await executeCapability("god_pvp", { player: "Dost" }, ctx);
    assert.equal(pvp.ok, false);
    assert.match(pvp.reply, /دوست/);
    assert.equal(attacks.length, 0, "هیچ ضربه‌ای نباید خورده شود");
    assert.equal(chats.length, 0, "هیچ فرمانی نباید اجرا شود");
    // فقط دوست اطراف است ← دشمنی نیست
    installBot({ onlyFriend: true });
    const none = await executeCapability("god_seal_on", {}, ctx);
    assert.equal(none.ok, false);
    assert.match(none.reply, /هدفی برای مهروموم پیدا نکردم/);
  });

  test("آزمون خطاها و توقف عملیات", async () => {
    // خطای هدف ناموجود — پیام دقیق
    const miss = await executeCapability("god_seal_on", { player: "Kasra" }, ctx);
    assert.equal(miss.ok, false);
    assert.match(miss.reply, /«Kasra» اینجا نیست/);
    // خطای فاصله — پیام دقیق با مسافت
    installBot({ aliDist: 50 });
    const far = await executeCapability("god_seal_on", { player: "Ali" }, ctx);
    assert.equal(far.ok, false);
    assert.match(far.reply, /دور است/);
    assert.match(far.reply, /24 بلوک/);
    // خطای منابع (جان کم) — پیام دقیق
    installBot({ health: 4 });
    const weak = await executeCapability("god_seal_on", { player: "Ali" }, ctx);
    assert.equal(weak.ok, false);
    assert.match(weak.reply, /جانم 4 است/);
    // توقف: باز کردن مهروموم یک هدف
    installBot();
    await executeCapability("god_seal_on", { player: "Ali" }, ctx);
    assert.ok(getSealedPlayers().includes("Ali"));
    chats.length = 0;
    const offOne = await executeCapability("god_seal_off", { player: "Ali" }, ctx);
    assert.equal(offOne.ok, true);
    assert.match(offOne.reply, /برداشته شد/);
    assert.ok(chats.includes("/effect clear Ali"));
    assert.ok(chats.includes("/gamemode survival Ali"));
    assert.ok(chats.includes("/tag Ali remove peak_sealed"));
    assert.ok(!getSealedPlayers().includes("Ali"));
    // توقف همگانی: همهٔ مهروموم‌ها + جاروی سمت سرور
    await executeCapability("god_seal_on", { player: "Ali" }, ctx);
    chats.length = 0;
    const offAll = await executeCapability("god_seal_off", {}, ctx);
    assert.equal(offAll.ok, true);
    assert.match(offAll.reply, /متوقف است/);
    assert.ok(chats.includes("/effect clear @a[tag=peak_sealed]"));
    assert.ok(chats.includes("/tag @a[tag=peak_sealed] remove peak_sealed"));
    assert.equal(getSealedPlayers().length, 0);
    // فرمان زبان طبیعی «مهروموم رو بردار» + همهٔ نمونه‌جمله‌های کاتالوگ
    assert.equal(matchFastAction("مهروموم رو بردار")?.id, "god_seal_off");
    assert.equal(matchFastAction("divine seal off")?.id, "god_seal_off");
    assert.equal(matchFastAction("نبرد خدایی روی Ali")?.id, "god_pvp");
    for (const sample of [
      "مهروموم خدایی",
      "مهروموم روی فلانی",
      "قفل خدایی بزن",
      "divine seal"
    ]) {
      assert.equal(matchFastAction(sample)?.id, "god_seal_on", `نمونهٔ «${sample}» باید مهروموم اجرا کند`);
    }
    for (const sample of [
      "مهروموم را باز کن",
      "همهٔ مهروموم‌ها رو باز کن"
    ]) {
      assert.equal(matchFastAction(sample)?.id, "god_seal_off", `نمونهٔ «${sample}» باید مهروموم باز کند`);
    }
    for (const sample of ["نبرد خدایی", "پی وی پی", "god pvp"]) {
      assert.equal(matchFastAction(sample)?.id, "god_pvp", `نمونهٔ «${sample}» باید نبرد خدایی اجرا کند`);
    }
    // عقب‌نشینی نبرد: وقتی مهروموم اجرا نمی‌شود ← فرار (توقف فشار)
    installBot({ health: 4 });
    const retreat = await executeCapability("god_pvp", { player: "Ali" }, ctx);
    assert.equal(retreat.ok, false);
    assert.match(retreat.reply, /عقب‌نشینی کردم/);
    assert.ok(controls.includes("sprint=true"), "فرار اجرا نشد");
  });
});
