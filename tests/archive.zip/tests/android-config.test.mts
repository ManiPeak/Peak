import { test } from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const read = (p: string) => fs.readFileSync(path.join(root, p), 'utf8')

test('android: پروژهٔ کامل و منسجم است (عین نسخهٔ PC — بدون سرور)', () => {
  // ساختار Gradle بدون wrapper (CI با setup-gradle 8.7 می‌سازد)
  for (const f of [
    'android/settings.gradle',
    'android/build.gradle',
    'android/gradle.properties',
    'android/app/build.gradle',
    'android/app/src/main/AndroidManifest.xml',
    'android/app/src/main/cpp/CMakeLists.txt',
    'android/app/src/main/cpp/node-jni.cpp',
    'android/app/src/main/java/com/peak/app/MainActivity.kt',
    'android/app/src/main/java/com/peak/app/NodeService.kt',
    'android/app/src/main/java/com/peak/app/AssetsInstaller.kt',
  ]) {
    assert.ok(fs.existsSync(path.join(root, f)), `${f} باید وجود داشته باشد`)
    assert.ok(read(f).trim().length > 50, `${f} نباید خالی باشد`)
  }
  // هیچ Gradle wrapper jar باینری در Git نیست
  assert.ok(!fs.existsSync(path.join(root, 'android/gradle/wrapper/gradle-wrapper.jar')))
})

test('android: نسخه از package.json خوانده می‌شود (منبع واحد حقیقت)', () => {
  const gradle = read('android/app/build.gradle')
  assert.match(gradle, /JsonSlurper/)
  assert.match(gradle, /package\.json/)
  assert.match(gradle, /versionName rootPkg\.version/)
  assert.ok(!/versionName\s+"1\./.test(gradle), 'نسخه نباید هاردکد شود')
  // applicationId و پورت عین نسخهٔ PC
  assert.match(gradle, /applicationId "com\.peak\.app"/)
  assert.match(read('android/app/src/main/java/com/peak/app/NodeService.kt'), /"-p", "3784"/)
})

test('android: اجرای کامل روی خود گوشی — node::Start + WebView محلی + cleartext', () => {
  const jni = read('android/app/src/main/cpp/node-jni.cpp')
  assert.match(jni, /#include <node\.h>/)
  assert.match(jni, /node::Start\(argc/)
  assert.match(jni, /chdir/)
  const manifest = read('android/app/src/main/AndroidManifest.xml')
  assert.match(manifest, /usesCleartextTraffic="true"/)
  assert.match(manifest, /FOREGROUND_SERVICE/)
  assert.match(manifest, /android\.permission\.INTERNET/)
  const activity = read('android/app/src/main/java/com/peak/app/MainActivity.kt')
  assert.match(activity, /127\.0\.0\.1:3784/)
  assert.match(activity, /WebView/)
  // libnode از npm — نه فایل باینری کامیت‌شده
  const prep = read('scripts/prepare-android-assets.mjs')
  assert.match(prep, /nodejs-mobile-react-native@18\.20\.4/)
  assert.match(prep, /npm.*pack|npm pack/)
})

test('android: پالایش assets عین build-exe.ps1 + ورک‌فلوی CI کامل', () => {
  const prep = read('scripts/prepare-android-assets.mjs')
  assert.match(prep, /swc-/)
  assert.match(prep, /@img/)
  assert.match(prep, /bedrock/)
  assert.match(prep, /minecraft-data/)
  const wf = read('.github/workflows/build-android.yml')
  assert.match(wf, /prepare-android-assets\.mjs/)
  assert.match(wf, /build-android-native\.sh/)
  assert.match(wf, /assembleRelease/)
  assert.match(wf, /setup-gradle/)
  assert.match(wf, /actions\/upload-artifact@/)
  // امضای keystore هرگز در مخزن نیست
  assert.ok(!fs.existsSync(path.join(root, 'android/keystore.jks')))
  assert.ok(!fs.existsSync(path.join(root, 'android/app/keystore.jks')))
})

test('android: جیت‌ایگنور خروجی‌های حجیم + مستندات صادقانه', () => {
  const gi = read('.gitignore')
  assert.match(gi, /android\/vendor\//)
  assert.match(gi, /android\/app\/src\/main\/assets\/app\//)
  assert.match(gi, /\*\.apk/)
  const doc = read('docs/ANDROID.md')
  assert.match(doc, /NOT TESTED/)
  assert.match(doc, /18\.20\.4/)
  assert.match(doc, /EOL/)
  assert.match(doc, /better-sqlite3/)
  // README باید به راهنمای اندروید اشاره کند
  assert.match(read('README.md'), /ANDROID\.md/)
})
