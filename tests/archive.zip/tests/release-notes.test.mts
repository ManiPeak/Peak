/**
 * تست‌های scripts/release-notes.mjs — یادداشت انتشار و راهنمای نصب ریلیز
 *
 * استخراج بخش درست نسخه از CHANGELOG، توقف در سربرگ بعدی و ساخت خروجی‌ها.
 */
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SCRIPT = path.join(ROOT, "scripts", "release-notes.mjs");

describe("یادداشت انتشار (release-notes.mjs)", () => {
  let tmp: string;

  before(() => {
    tmp = fs.mkdtempSync(path.join(os.tmpdir(), "peak-relenotes-"));
    // فیکسچر کوچک: دو نسخه در CHANGELOG تا درستیِ «بخش همین نسخه» سنجیده شود
    fs.writeFileSync(
      path.join(tmp, "package.json"),
      JSON.stringify({ name: "peak", version: "1.0.2" }),
      "utf8"
    );
    fs.mkdirSync(path.join(tmp, "docs"));
    fs.writeFileSync(
      path.join(tmp, "docs", "EXE-GUIDE.md"),
      "# راهنمای نصب تستی\n",
      "utf8"
    );
    fs.writeFileSync(
      path.join(tmp, "CHANGELOG.md"),
      [
        "# تاریخچه",
        "",
        "## نسخهٔ ۱.۰.۲ — «عنوان جدید\"",
        "",
        "* ویژگی جدید الف",
        "",
        "## نسخهٔ ۱.۰.۱ — «عنوان قدیمی\"",
        "",
        "* ویژگی قدیمی ب",
        ""
      ].join("\n"),
      "utf8"
    );
  });

  after(() => {
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  test("بخش نسخهٔ فعلی را درست استخراج می‌کند و در سربرگ بعدی می‌ایستد", () => {
    execFileSync(process.execPath, [SCRIPT], { cwd: tmp });
    const notes = fs.readFileSync(path.join(tmp, "release-notes.md"), "utf8");
    assert.match(notes, /نسخهٔ ۱\.۰\.۲/);
    assert.ok(notes.includes("ویژگی جدید الف"), "محتوای نسخهٔ ۱.۰.۲ باید باشد");
    assert.ok(!notes.includes("ویژگی قدیمی ب"), "محتوای نسخهٔ قدیمی نباید نشت کند");
    // بخش‌های ضروری ریلیز
    assert.ok(notes.includes("Peak-Setup-1.0.2.exe"));
    assert.ok(notes.includes("INSTALL-GUIDE.md"));
    assert.ok(notes.includes("SmartScreen"));
    // راهنمای نصب کپی می‌شود
    const guide = fs.readFileSync(path.join(tmp, "INSTALL-GUIDE.md"), "utf8");
    assert.ok(guide.includes("راهنمای نصب تستی"));
  });

  test("روی CHANGELOG واقعی پروژه هم بخش ۱.۰.۲ را پیدا می‌کند", () => {
    execFileSync(process.execPath, [SCRIPT], { cwd: ROOT });
    const notes = fs.readFileSync(path.join(ROOT, "release-notes.md"), "utf8");
    assert.match(notes, /نسخهٔ ۱\.۰\.۲/);
    assert.ok(notes.includes("مهروموم"), "یادداشت ۱.۰.۲ باید ویژگی‌های Divine Seal را داشته باشد");
  });
});
