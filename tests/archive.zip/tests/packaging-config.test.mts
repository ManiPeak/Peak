/**
 * تست‌های پیکربندی بسته‌بندی ویندوز — پیشگیری از کلاس خطای «Missing Shortcut»
 *
 * میان‌برهای دسکتاپ/منوی استارت وقتی «Missing Shortcut» می‌شوند که هدفشان نباشد.
 * ریشهٔ قابل پیشگیری در config: نام اجرایی/میان‌بر که بین نسخه‌ها عوض شود یا غیر ASCII باشد.
 * این تست‌ها نام‌ها را در هر دو config (electron-builder.js و build-exe.ps1) پین می‌کنند.
 */
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);

// بی‌صدا کردن هشدار vendor/node هنگام require کردن config
const originalWarn = console.warn;
console.warn = () => undefined;
const cfg = require(path.join(ROOT, "electron-builder.js")) as {
  productName: string;
  executableName?: string;
  nsis: {
    createDesktopShortcut: boolean;
    createStartMenuShortcut: boolean;
    shortcutName: string;
    artifactName: string;
    installerSidebar?: string;
    installerHeaderImage?: string;
  };
  portable: { artifactName: string };
};
console.warn = originalWarn;

describe("بسته‌بندی ویندوز — نام‌های پین‌شده برای میان‌برهای سالم", () => {
  test("فایل اجرایی نصب‌شده همیشه Peak.exe است (رفع کلاس خطای Missing Shortcut)", () => {
    assert.equal(cfg.productName, "Peak");
    assert.equal(
      cfg.executableName,
      "Peak",
      "executableName باید پین شود تا میان‌برها به هدف گم‌شده اشاره نکنند"
    );
    assert.equal(cfg.nsis.createDesktopShortcut, true);
    assert.equal(cfg.nsis.createStartMenuShortcut, true);
  });

  test("نام میان‌بر ASCII است (NSIS با کاراکتر غیرلاتین میان‌بر خراب می‌سازد)", () => {
    assert.equal(cfg.nsis.shortcutName, "Peak");
    assert.match(cfg.nsis.shortcutName, /^[\x20-\x7E]+$/);
  });

  test("نام خروجی‌ها الگوی پایدار نسخه‌دار دارند", () => {
    assert.match(cfg.nsis.artifactName, /^Peak-Setup-\$\{version\}\.\$\{ext\}$/);
    assert.match(cfg.portable.artifactName, /^Peak-Portable-\$\{version\}\.\$\{ext\}$/);
  });

  test("اسکریپت ساخت ویندوز (config تولیدی) همان نام‌ها را دارد", () => {
    const ps = fs.readFileSync(path.join(ROOT, "scripts", "build-exe.ps1"), "utf8");
    assert.match(ps, /'executableName: Peak'/);
    assert.match(ps, /'\s+shortcutName: Peak'/);
    assert.match(ps, /'\s+createDesktopShortcut: true'/);
    assert.match(ps, /'\s+createStartMenuShortcut: true'/);
    assert.match(ps, /'\s+artifactName: "Peak-Setup-\$\{version\}\.\$\{ext\}"'/);
    assert.match(ps, /'\s+artifactName: "Peak-Portable-\$\{version\}\.\$\{ext\}"'/);
  });

  test("نسخه در همه‌جا هماهنگ است (package.json = package-lock)", () => {
    const pkg = JSON.parse(
      fs.readFileSync(path.join(ROOT, "package.json"), "utf8")
    ) as { version: string };
    const lock = JSON.parse(
      fs.readFileSync(path.join(ROOT, "package-lock.json"), "utf8")
    ) as { version: string; packages: Record<string, { version?: string }> };
    assert.match(pkg.version, /^\d+\.\d+\.\d+$/);
    assert.equal(lock.version, pkg.version, "package-lock نسخهٔ ریشه باید هماهنگ باشد");
    assert.equal(
      lock.packages[""]?.version,
      pkg.version,
      "package-lock packages[\"\"] باید هماهنگ باشد"
    );
  });

  test("گرافیک ویزارد نصب (BMP) موجود است و در هر دو config معرفی شده", () => {
    for (const name of ["installer-sidebar.bmp", "installer-header.bmp"]) {
      const p = path.join(ROOT, "build", name);
      assert.ok(fs.existsSync(p), `build/${name} باید وجود داشته باشد`);
      const head = fs.readFileSync(p).subarray(0, 2).toString("latin1");
      assert.equal(head, "BM", `build/${name} باید BMP واقعی باشد`);
      assert.ok(fs.statSync(p).size > 10_000, `build/${name} نباید خالی باشد`);
    }
    const ps = fs.readFileSync(path.join(ROOT, "scripts", "build-exe.ps1"), "utf8");
    assert.match(ps, /installerSidebar: build\/installer-sidebar\.bmp/);
    assert.match(ps, /installerHeaderImage: build\/installer-header\.bmp/);
    assert.equal(cfg.nsis.installerSidebar, "build/installer-sidebar.bmp");
    assert.equal(cfg.nsis.installerHeaderImage, "build/installer-header.bmp");
  });
});
