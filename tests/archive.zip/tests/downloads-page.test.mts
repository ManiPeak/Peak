/**
 * تست‌های صفحهٔ نصب ویندوز (src/app/downloads/page.tsx)
 *
 * لینک‌های این صفحه، درگاه اصلی دانلود کاربران‌اند؛ این تست‌ها مطمئن می‌شوند
 * لینک‌ها ثابت و درست بمانند (نام‌های …-Latest.exe بدون شمارهٔ نسخه).
 */
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const page = fs.readFileSync(
  path.join(ROOT, "src", "app", "downloads", "page.tsx"),
  "utf8"
);

describe("صفحهٔ نصب ویندوز — لینک‌ها و محتوای کاربری", () => {
  test("لینک‌های دانلود به نام‌های ثابت Latest اشاره می‌کنند", () => {
    assert.ok(
      page.includes("/download/Peak-Setup-Latest.exe"),
      "لینک نصب‌کننده باید …/Peak-Setup-Latest.exe باشد"
    );
    assert.ok(
      page.includes("/download/Peak-Portable-Latest.exe"),
      "لینک پرتابل باید …/Peak-Portable-Latest.exe باشد"
    );
    assert.ok(page.includes("/releases/latest"), "پایهٔ لینک باید releases/latest باشد");
    assert.ok(page.includes("ManiPeak/Peak"), "ریپو باید ManiPeak/Peak باشد");
    assert.ok(!page.includes("your-repo"), "جای‌نگهدار your-repo نباید بماند");
  });

  test("شمارهٔ نسخه هاردکد نیست و از package.json خوانده می‌شود", () => {
    assert.match(page, /from "\.\.\/\.\.\/\.\.\/package\.json"/);
    assert.ok(!page.includes("Peak-Setup-1.0.1"), "مثال نسخهٔ کهنه نباید بماند");
  });

  test("راهنمای نصب و عیب‌یابی‌های ضروری در صفحه هستند", () => {
    for (const needle of [
      "فقط محل نصب", // دستور نصب
      "SmartScreen", // هشدار امضا
      "Unblock",
      "Missing Shortcut", // عیب‌یابی میان‌بر
      "peak-log.txt", // لاگ خطا
      "APPDATA" // مسیر داده‌های پرتابل
    ]) {
      assert.ok(page.includes(needle), `«${needle}» باید در صفحهٔ نصب باشد`);
    }
  });
});
